package com.raidalert

import android.app.Notification
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class RaidListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return

        val prefs = Prefs(this)
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val full = "$title $text $big"

        val game = prefs.gamePackage

        // Режим поиска: пока пакет игры не задан, пишем лог всех уведомлений,
        // чтобы найти пакет и текст рейд-уведомления. Данные хранятся только на устройстве.
        if (game.isEmpty()) {
            prefs.addLog("${sbn.packageName} | $title | $text")
            return
        }
        if (sbn.packageName != game) return

        prefs.addLog("${sbn.packageName} | $title | $text")

        val hit = prefs.keywords.split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .any { full.contains(it, ignoreCase = true) }
        if (hit) Spammer.start(this)
    }

    override fun onListenerDisconnected() {
        if (Build.VERSION.SDK_INT >= 24) {
            requestRebind(ComponentName(this, RaidListener::class.java))
        }
    }
}
