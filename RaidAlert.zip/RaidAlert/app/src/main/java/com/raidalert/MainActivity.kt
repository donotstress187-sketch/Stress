package com.raidalert

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var etPackage: EditText
    private lateinit var etKeywords: EditText
    private lateinit var etTitle: EditText
    private lateinit var etBody: EditText
    private lateinit var etInterval: EditText
    private lateinit var etCount: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        status = findViewById(R.id.status)
        log = findViewById(R.id.log)
        etPackage = findViewById(R.id.etPackage)
        etKeywords = findViewById(R.id.etKeywords)
        etTitle = findViewById(R.id.etTitle)
        etBody = findViewById(R.id.etBody)
        etInterval = findViewById(R.id.etInterval)
        etCount = findViewById(R.id.etCount)

        etPackage.setText(prefs.gamePackage)
        etKeywords.setText(prefs.keywords)
        etTitle.setText(prefs.title)
        etBody.setText(prefs.body)
        etInterval.setText(prefs.intervalMs.toString())
        etCount.setText(prefs.count.toString())

        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            save()
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            save()
            Spammer.start(this)
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { Spammer.stop(this) }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refresh() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            prefs.clearLog()
            refresh()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    private fun save() {
        prefs.gamePackage = etPackage.text.toString()
        prefs.keywords = etKeywords.text.toString()
        prefs.title = etTitle.text.toString()
        prefs.body = etBody.text.toString()
        prefs.intervalMs = etInterval.text.toString().toLongOrNull() ?: 1500L
        prefs.count = etCount.text.toString().toIntOrNull() ?: 60
    }

    private fun refresh() {
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        status.text = if (enabled) "✅ Доступ к уведомлениям выдан" else "❌ Доступ к уведомлениям НЕ выдан"
        val l = prefs.getLog()
        log.text = if (l.isEmpty()) "Лог пуст" else l
    }
}
