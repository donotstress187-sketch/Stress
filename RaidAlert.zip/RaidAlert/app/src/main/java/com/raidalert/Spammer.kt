package com.raidalert

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Spammer {
    private const val CHANNEL = "raid_alarm"
    private const val BASE_ID = 1000
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var sent = 0
    private var total = 0

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        if (running) return
        val prefs = Prefs(app)
        running = true
        sent = 0
        total = prefs.count
        ensureChannel(app)
        handler.post(object : Runnable {
            override fun run() {
                if (!running) return
                if (sent >= total) {
                    running = false
                    return
                }
                post(app, prefs, sent)
                sent++
                handler.postDelayed(this, prefs.intervalMs)
            }
        })
    }

    fun stop(ctx: Context) {
        val app = ctx.applicationContext
        running = false
        handler.removeCallbacksAndMessages(null)
        val nm = NotificationManagerCompat.from(app)
        for (i in 0 until total.coerceAtLeast(sent)) nm.cancel(BASE_ID + i)
    }

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, "Тревога о рейде", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Спам-уведомления при рейде"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 800)
            enableLights(true)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        nm.createNotificationChannel(ch)
    }

    @SuppressLint("MissingPermission")
    private fun post(ctx: Context, prefs: Prefs, n: Int) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, StopReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(prefs.title)
            .setContentText(prefs.body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "СТОП", stop)
            .build()
        nm.notify(BASE_ID + n, notif)
    }
}
